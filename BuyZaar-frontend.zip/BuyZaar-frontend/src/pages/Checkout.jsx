function Checkout() {
  return <div className="p-10 text-2xl">Checkout Page</div>;
}
export default Checkout;
