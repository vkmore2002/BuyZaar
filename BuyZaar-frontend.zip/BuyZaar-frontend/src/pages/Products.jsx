function Products() {
  return <div className="p-10 text-2xl">Products Page</div>;
}
export default Products;
