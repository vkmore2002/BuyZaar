function ProductDetails() {
  return <div className="p-10 text-2xl">Product Details Page</div>;
}
export default ProductDetails;
