function Dashboard() {
  return <div className="p-10 text-2xl font-bold">Admin Dashboard</div>;
}

export default Dashboard;
