function NotFound() {
  return <div className="p-10 text-2xl text-red-500">404 - Page Not Found</div>;
}
export default NotFound;
