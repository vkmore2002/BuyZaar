function Home() {
  return <div className="p-10 text-2xl">Home Page</div>;
}
export default Home;
