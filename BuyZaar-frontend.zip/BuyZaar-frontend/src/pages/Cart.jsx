function Cart() {
  return <div className="p-10 text-2xl">Cart Page</div>;
}
export default Cart;
